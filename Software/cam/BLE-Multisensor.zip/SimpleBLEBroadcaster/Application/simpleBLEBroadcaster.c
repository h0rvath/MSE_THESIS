/**************************************************************************************************
  Filename:       simpleBLEBroadcaster.c
  Revised:        $Date: 2016-01-07 16:59:59 -0800 (Thu, 07 Jan 2016) $
  Revision:       $Revision: 44594 $

  Description:    This file contains the Simple BLE Broadcaster sample application 
                  for use with the CC2650 Bluetooth Low Energy Protocol Stack.

  Copyright 2011 - 2015 Texas Instruments Incorporated. All rights reserved.

  IMPORTANT: Your use of this Software is limited to those specific rights
  granted under the terms of a software license agreement between the user
  who downloaded the software, his/her employer (which must be your employer)
  and Texas Instruments Incorporated (the "License").  You may not use this
  Software unless you agree to abide by the terms of the License. The License
  limits your use, and you acknowledge, that the Software may not be modified,
  copied or distributed unless embedded on a Texas Instruments microcontroller
  or used solely and exclusively in conjunction with a Texas Instruments radio
  frequency transceiver, which is integrated into your product.  Other than for
  the foregoing purpose, you may not use, reproduce, copy, prepare derivative
  works of, modify, distribute, perform, display or sell this Software and/or
  its documentation for any purpose.

  YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE
  PROVIDED �AS IS� WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
  INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE,
  NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL
  TEXAS INSTRUMENTS OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER CONTRACT,
  NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER
  LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
  INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE
  OR CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT
  OF SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
  (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.

  Should you have any questions regarding your right to use this Software,
  contact Texas Instruments Incorporated at www.TI.com.
**************************************************************************************************/

/*********************************************************************
 * INCLUDES
 */

#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Clock.h>
#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/knl/Queue.h>

#include "hci.h"
#include "gatt.h"
#include "gapgattserver.h"
#include "gattservapp.h"

#include "broadcaster.h"
#include "gapbondmgr.h"

#include "osal_snv.h"
#include "ICallBleAPIMSG.h"

#include "util.h"
#include "board_lcd.h"
#include "Board.h"
   
#include "simpleBLEBroadcaster.h"

#include <ti/drivers/lcd/LCDDogm1286.h>
#include "scif.h" // TODO: CAM: include for SCS
#include <driverlib/aon_batmon.h> // TODO: CAM: include for battery measurment
/*********************************************************************
 * MACROS
 */

/*********************************************************************
 * CONSTANTS
 */

// What is the advertising interval when device is discoverable (units of 625us, 160=100ms)
#define DEFAULT_ADVERTISING_INTERVAL         160 // 1600 =  1s

// Task configuration
#define SBB_TASK_PRIORITY                     1

#ifndef SBB_TASK_STACK_SIZE
#define SBB_TASK_STACK_SIZE                   600
#endif
  
// Internal Events for RTOS application
#define SBB_STATE_CHANGE_EVT                  0x0001
#define SBB_KEY_CHANGE_EVT                    0x0002

// TODO: CAM: GPIO and SCS Events
#define SBB_PERIODIC_EVT                      0x0004 // CAM: added support for periodic events
#define SBB_SC_TASK_ALERT					  0x0008 // CAM: added support for Sensor Controller Task Allert
#define SBB_ACCEL_EVT						  0x0010 // CAM: added support for Accelerometer Interrupt
#define SBB_PIR_EVT							  0x0020 // CAM: added support for PIR Interrupt
#define SBB_REED_EVT						  0x0040 // CAM: added support for REED Door sensor


// TODO: CAM: adverted Events
#define SC_TASK_ALERT					  0x01
#define ACCEL_EVT						  0x02
#define PIR_EVT							  0x04
#define REED_EVT						  0x08
#define KEY_CHANGE_EVT					  0x10
#define PERIODIC_EVT					  0x20


// TODO: CAM: Internal stack events
#define SBB_ADV_CB_EVT						  0x0001 // CAM: added support for Advertisement End Event

// TODO: CAM:  How often to perform periodic events (in msec)
#define SBB_PERIODIC_EVT_PERIOD               60000

// TODO: CAM: What ist the SCS RTC tick intervall (Bits 31:16 = seconds, Bits 15:0 = 1/65536 of a second)
#define SCIF_RTC_TICKS						  0x00140000

#define BEACON_FEATURE


// TODO: CAM: indexing sensorData array
#define MSB_LUX 2
#define LSB_LUX 3
#define MSB_Temp 4
#define LSB_Temp 5
#define MSB_Humid 6
#define LSB_Humid 7
#define MSB_Acc_X 8
#define LSB_Acc_X 9
#define MSB_Acc_Y 10
#define LSB_Acc_Y 11
#define MSB_Acc_Z 12
#define LSB_Acc_Z 13
#define UPDATE_IRQ 14
#define BATTERY_LEVEL 15
#define TX_COUNTER 16
/*********************************************************************
 * TYPEDEFS
 */

// App event passed from profiles.
typedef struct
{
  appEvtHdr_t hdr; // Event header.
} sbbEvt_t;

/*********************************************************************
 * GLOBAL VARIABLES
 */

/*********************************************************************
 * EXTERNAL VARIABLES
 */

/*********************************************************************
 * EXTERNAL FUNCTIONS
 */

/*********************************************************************
 * LOCAL VARIABLES
 */

// -------------------------------------------------------------------
// TODO: CAM: adding local variables
// -------------------------------------------------------------------

// CAM: adding Pin driver handles and Pin states
static PIN_Handle pinHandle;
static PIN_State pinState;

// CAM: events flag for internal application events.
static uint16_t events;

// CAM: store PIR, ACCEL and REED events for Advertisment
static uint8_t sensorEvents;

// CAM: Clock instances for internal periodic events.
static Clock_Struct periodicClock;

// CAM: variables to turn on/off advertisment
static uint8_t AdvEnable = 1;
static uint8_t AdvDisable = 0;

// CAM: Store callibration values for Temperature and Humidity
static int16_t T0_degC;
static int16_t T1_degC;
static int16_t T0_out;
static int16_t T1_out;
static int16_t H0Rh;
static int16_t H1Rh;
static int16_t H0T0_out;
static int16_t H1T0_out;
static int16_t Tout;
static int16_t Hout;
static int16_t Accel_X_out;
static int16_t Accel_Y_out;
static int16_t Accel_Z_out;
static uint16_t Light;
static int16_t Temperature;
static uint16_t Humidity;


// CAM: init flag for reading callibration data
static uint8_t FirstScsEvent = 1;
// CAM: flag for advertisement
static uint8_t isActive = 1;
// CAM: flag for Accel Events
static uint8_t processAccelEvents = 1;
// CAM: flag for PIR Event
static uint8_t processPirEvents = 1;
// CAM: flag for REED Events
static uint8_t processReedEvents = 1;
// CAM: flag for SCS Events
static uint8_t processScsEvents = 1;
// CAM: flag for periodic events
static uint8_t processPeriodicEvents = 1;
// CAM: init tx_counter for identifying duplicated transimssions
static uint8_t tx_counter = 0;


// CAM: new advData
static uint8 AdlAdvertData[] = {
		  0x11,   // length of this data
		  GAP_ADTYPE_MANUFACTURER_SPECIFIC,
		  0xFF, // MSB Helligkeit
		  0xFF, // LSB Helligkeit
		  0xFF, // MSB Temperatur
		  0xFF, // LSB Temperatur
		  0x0D, // MSB Luftfeuchte
		  0x00, // LSB Luftfeuchte
		  0x02, // MSB Accel X
		  0x15, // LSB Accel X
		  0x00, // MSB Accel Y
		  0x00, // LSB Accel Y
		  0x00, // MSB Accel Z
		  0x00, // LSB Accel Z
		  0x00, // Update and IRQ-Flags
		  0x00, // Batterie Level
		  0x00, // Reserve
		  0x00, // Reserve

};

// -------------------------------------------------------------------
// TODO: CAM: adding local variable END
// -------------------------------------------------------------------


// Entity ID globally used to check for source and/or destination of messages
static ICall_EntityID selfEntity;

// Semaphore globally used to post events to the application thread
static ICall_Semaphore sem;

// Queue object used for app messages
static Queue_Struct appMsg;
static Queue_Handle appMsgQueue;

// Task configuration
Task_Struct sbbTask;
Char sbbTaskStack[SBB_TASK_STACK_SIZE];

// GAP - SCAN RSP data (max size = 31 bytes)
static uint8 scanRspData[] =
{
  // complete name
  0x15,   // length of this data
  GAP_ADTYPE_LOCAL_NAME_COMPLETE,
  0x53,   // 'S'
  0x69,   // 'i'
  0x6d,   // 'm'
  0x70,   // 'p'
  0x6c,   // 'l'
  0x65,   // 'e'
  0x42,   // 'B'
  0x4c,   // 'L'
  0x45,   // 'E'
  0x42,   // 'B'
  0x72,   // 'r'
  0x6f,   // 'o'
  0x61,   // 'a'
  0x64,   // 'd'
  0x63,   // 'c'
  0x61,   // 'a'
  0x73,   // 's'
  0x74,   // 't'
  0x65,   // 'e'
  0x72,   // 'r'

  // Tx power level
  0x02,   // length of this data
  GAP_ADTYPE_POWER_LEVEL,
  0       // 0dBm  
};

//// GAP - Advertisement data (max size = 31 bytes, though this is
//// best kept short to conserve power while advertisting)
//static uint8 advertData[] =
//{
//  // Flags; this sets the device to use limited discoverable
//  // mode (advertises for 30 seconds at a time) instead of general
//  // discoverable mode (advertises indefinitely)
//  0x02,   // length of this data
//  GAP_ADTYPE_FLAGS,
//  GAP_ADTYPE_FLAGS_BREDR_NOT_SUPPORTED,
//
//#ifndef BEACON_FEATURE
//
//  // three-byte broadcast of the data "1 2 3"
//  0x04,   // length of this data including the data type byte
//  GAP_ADTYPE_MANUFACTURER_SPECIFIC, // manufacturer specific adv data type
//  1,
//  2,
//  3
//
//#else
//
//  // 25 byte beacon advertisement data
//  // Preamble: Company ID - 0x000D for TI, refer to https://www.bluetooth.org/en-us/specification/assigned-numbers/company-identifiers
//  // Data type: Beacon (0x02)
//  // Data length: 0x15
//  // UUID: 00000000-0000-0000-0000-000000000000 (null beacon)
//  // Major: 1 (0x0001)
//  // Minor: 1 (0x0001)
//  // Measured Power: -59 (0xc5)
//  0x1A, // length of this data including the data type byte
//  GAP_ADTYPE_MANUFACTURER_SPECIFIC, // manufacturer specific adv data type
//  0x0D, // Company ID - Fixed
//  0x00, // Company ID - Fixed
//  0x02, // Data Type - Fixed
//  0x15, // Data Length - Fixed
//  0x00, // UUID - Variable based on different use cases/applications
//  0x00, // UUID
//  0x00, // UUID
//  0x00, // UUID
//  0x00, // UUID
//  0x00, // UUID
//  0x00, // UUID
//  0x00, // UUID
//  0x00, // UUID
//  0x00, // UUID
//  0x00, // UUID
//  0x00, // UUID
//  0x00, // UUID
//  0x00, // UUID
//  0x00, // UUID
//  0x00, // UUID
//  0x00, // Major
//  0x01, // Major
//  0x00, // Minor
//  0x01, // Minor
//  0xc5  // Power - The 2's complement of the calibrated Tx Power
//
//#endif // !BEACON_FEATURE
//};








/*********************************************************************
 * LOCAL FUNCTIONS
 */

static void SimpleBLEBroadcaster_init(void);
static void SimpleBLEBroadcaster_taskFxn(UArg a0, UArg a1);

static void SimpleBLEBroadcaster_processStackMsg(ICall_Hdr *pMsg);
static void SimpleBLEBroadcaster_processAppMsg(sbbEvt_t *pMsg);
static void SimpleBLEBroadcaster_processStateChangeEvt(gaprole_States_t newState);

static void SimpleBLEBroadcaster_stateChangeCB(gaprole_States_t newState);

void SimpleBLEBroadcaster_initLCD(void);

// -------------------------------------------------------------------
// TODO: CAM: New function descriptions START
// -------------------------------------------------------------------
// CAM: added function descrition for clockHandler and pinInterruptHandler
static void SimpleBLEBroadcaster_clockHandler(UArg arg);
// CAM: added pinInterruptHandler function desctription
static void pinInterruptHandler(PIN_Handle handle, PIN_Id pinId);
// CAM: added blinkLED function desctription
static void blinkLED(uint8_t times, uint32_t delay);
// CAM: added scCtrlReadyCallback function description
static void scCtrlReadyCallback(void);
// CAM: added scTaskAlertCallback function desription
void scTaskAlertCallback(void);
// CAM: added getHumidity function description
void getHumidity(uint16_t * value);
// CAM: added getTemperature function description
void getTemperature(int16_t *value);
// CAM: added processSensorData function description
void processSensorData(void);
// CAM: added updateData function description
void updateAdvertismentData(void);
// CAM: handle alle Events from sensors
void processAppSpecificEvents(void);
// CAM: initialize SensorControllerStudio
void initSensorControllerStudio(void);

// -------------------------------------------------------------------
// TODO: CAM: New function description END
// -------------------------------------------------------------------


/*********************************************************************
 * PROFILE CALLBACKS
 */

// GAP Role Callbacks
static gapRolesCBs_t simpleBLEBroadcaster_BroadcasterCBs =
{
  SimpleBLEBroadcaster_stateChangeCB   // Profile State Change Callbacks
};

/*********************************************************************
 * PUBLIC FUNCTIONS
 */

/*********************************************************************
 * @fn      SimpleBLEBroadcaster_createTask
 *
 * @brief   Task creation function for the Simple BLE Broadcaster.
 *
 * @param   none
 *
 * @return  none
 */
void SimpleBLEBroadcaster_createTask(void)
{
  Task_Params taskParams;
    
  // Configure task
  Task_Params_init(&taskParams);
  taskParams.stack = sbbTaskStack;
  taskParams.stackSize = SBB_TASK_STACK_SIZE;
  taskParams.priority = SBB_TASK_PRIORITY;
  
  Task_construct(&sbbTask, SimpleBLEBroadcaster_taskFxn, &taskParams, NULL);
}

/*********************************************************************
 * @fn      SimpleBLEBroadcaster_init
 *
 * @brief   Initialization function for the Simple BLE Broadcaster App
 *          Task. This is called during initialization and should contain
 *          any application specific initialization (ie. hardware
 *          initialization/setup, table initialization, power up
 *          notification ...).
 *
 * @param   none
 *
 * @return  none
 */
static void SimpleBLEBroadcaster_init(void)
{
	// ******************************************************************
  // N0 STACK API CALLS CAN OCCUR BEFORE THIS CALL TO ICall_registerApp
  // ******************************************************************
  // Register the current thread as an ICall dispatcher application
  // so that the application can send and receive messages.
  ICall_registerApp(&selfEntity, &sem);
    
  // Hard code the DB Address till CC2650 board gets its own IEEE address
  //uint8 bdAddress[B_ADDR_LEN] = { 0x33, 0x33, 0x33, 0x33, 0x33, 0x33 };
  //HCI_EXT_SetBDADDRCmd(bdAddress);
  
  // Create an RTOS queue for message from profile to be sent to app.
  appMsgQueue = Util_constructQueue(&appMsg);
  


  // ----------------------------------------------------------------------------
  // TODO: CAM: start of custom modification
  // ----------------------------------------------------------------------------
  // CAM: increase output power to 5dBm
  HCI_EXT_SetTxPowerCmd(HCI_EXT_TX_POWER_5_DBM);

  // CAM: init pins
  pinHandle = PIN_open(&pinState, BoardGpioInitTable);

//  if(!pinHandle) {
//      System_abort("Error initializing board pins\n");
//  }

  // CAM: register Key interrupt callback and set interrupt
  PIN_registerIntCb(pinHandle, pinInterruptHandler);
  PIN_setInterrupt(pinHandle, Board_KEY | PIN_IRQ_NEGEDGE);

  // CAM: register Accelerometer interrupt
  PIN_setInterrupt(pinHandle, Board_ACCEL_INT2 | PIN_IRQ_POSEDGE);

  // CAM: register PIR interrupt
  PIN_setInterrupt(pinHandle, Board_PIR_IRQ | PIN_IRQ_POSEDGE);

  // CAM: register REED interrupt
  PIN_setInterrupt(pinHandle, Board_REED | PIN_IRQ_BOTHEDGES);

  // CAM: enable PIR_Power
  if (processPirEvents == 1){
	  PIN_setOutputValue(pinHandle, Board_PIR_PWR, 1);
  }


  // CAM: Create one-shot clocks for internal periodic events.
  Util_constructClock(&periodicClock, SimpleBLEBroadcaster_clockHandler,
                      SBB_PERIODIC_EVT_PERIOD, 0, true, SBB_PERIODIC_EVT);

  // CAM: Add an advertisment end event
  HCI_EXT_AdvEventNoticeCmd(selfEntity,SBB_ADV_CB_EVT);

  // CAM: enable battery measurment
  AONBatMonEnable();
  // ----------------------------------------------------------------------------
  // TODO: CAM: custom modification end
  // ----------------------------------------------------------------------------




#ifdef TI_DRIVERS_LCD_INCLUDED
  //Enable the 3V3 Domain and open LCD
  Board_openLCD();
#endif //TI_DRIVERS_LCD_INCLUDED
  
  // Setup the GAP Broadcaster Role Profile
  {
    // For all hardware platforms, device starts advertising upon initialization
    uint8_t initial_advertising_enable = TRUE;

    // By setting this to zero, the device will go into the waiting state after
    // being discoverable for 30.72 second, and will not being advertising again
    // until the enabler is set back to TRUE
    uint16_t gapRole_AdvertOffTime = 0;
    uint8_t channels = GAP_ADVCHAN_ALL;
      
#ifndef BEACON_FEATURE
    uint8_t advType = GAP_ADTYPE_ADV_SCAN_IND; // use scannable undirected adv
#else
    uint8_t advType = GAP_ADTYPE_ADV_NONCONN_IND; // use non-connectable adv
#endif // !BEACON_FEATURE
    
    // Set the GAP Role Parameters
    GAPRole_SetParameter(GAPROLE_ADVERT_ENABLED, sizeof(uint8_t), 
                         &initial_advertising_enable);
    GAPRole_SetParameter(GAPROLE_ADVERT_OFF_TIME, sizeof(uint16_t), 
                         &gapRole_AdvertOffTime);
    
    GAPRole_SetParameter(GAPROLE_SCAN_RSP_DATA, sizeof (scanRspData),
                         scanRspData);
    GAPRole_SetParameter(GAPROLE_ADVERT_DATA, sizeof(AdlAdvertData), AdlAdvertData);

    GAPRole_SetParameter(GAPROLE_ADV_EVENT_TYPE, sizeof(uint8_t), &advType);

    // TODO: CAM: advertise on all channels
    GAPRole_SetParameter(GAPROLE_ADV_CHANNEL_MAP, sizeof(uint8_t), &channels);
  }

  // Set advertising interval
  {
    uint16_t advInt = DEFAULT_ADVERTISING_INTERVAL;

    GAP_SetParamValue(TGAP_LIM_DISC_ADV_INT_MIN, advInt);
    GAP_SetParamValue(TGAP_LIM_DISC_ADV_INT_MAX, advInt);
    GAP_SetParamValue(TGAP_GEN_DISC_ADV_INT_MIN, advInt);
    GAP_SetParamValue(TGAP_GEN_DISC_ADV_INT_MAX, advInt);
  }
  
  // Start the Device
  VOID GAPRole_StartDevice(&simpleBLEBroadcaster_BroadcasterCBs);
  
  // LCD_WRITE_STRING("BLE Broadcaster", LCD_PAGE0); TODO: removed
}

/*********************************************************************
 * @fn      SimpleBLEBroadcaster_processEvent
 *
 * @brief   Application task entry point for the Simple BLE Broadcaster.
 *
 * @param   none
 *
 * @return  none
 */
static void SimpleBLEBroadcaster_taskFxn(UArg a0, UArg a1)
{
  // Initialize application
  SimpleBLEBroadcaster_init();

  // TODO: CAM: init sensor controller studio
  initSensorControllerStudio();
  int tx_repeat_counter = 0;

  // Application main loop
  for (;;)
  {
    // Get the ticks since startup
    uint32_t tickStart = Clock_getTicks();

    // Waits for a signal to the semaphore associated with the calling thread.
    // Note that the semaphore associated with a thread is signaled when a
    // message is queued to the message receive queue of the thread or when
    // ICall_signal() function is called onto the semaphore.
    ICall_Errno errno = ICall_wait(ICALL_TIMEOUT_FOREVER);

    if (errno == ICALL_ERRNO_SUCCESS)
    {
      ICall_EntityID dest;
      ICall_ServiceEnum src;
      ICall_HciExtEvt *pMsg = NULL;

      if (ICall_fetchServiceMsg(&src, &dest,
                                (void **)&pMsg) == ICALL_ERRNO_SUCCESS)
      {
        if ((src == ICALL_SERVICE_CLASS_BLE) && (dest == selfEntity))
        {
        	ICall_Event *pEvt = (ICall_Event *)pMsg;
        	// ---------------------------------------------------------------------
        	// Check for BLE stack events first
        	// ---------------------------------------------------------------------
            if (pEvt->signature == 0xffff){
            	// TODO: CAM: Check for end of advertsisment event
            	if (pEvt->event_flag & SBB_ADV_CB_EVT)
            	{
            		blinkLED(1,20e3);
            		if (tx_repeat_counter < 2){
            			tx_repeat_counter = tx_repeat_counter +1;
            			//tx_counter = tx_counter +1; // Moved from updateAdvertismentData
            		}else{
            			GAPRole_SetParameter(GAPROLE_ADVERT_ENABLED, sizeof(uint8_t), &AdvDisable);
            			tx_repeat_counter = 0;
            			tx_counter = tx_counter +1; // Moved from updateAdvertismentData
            		}

            	}
            }
            else
            {
            	// Process inter-task message
            	SimpleBLEBroadcaster_processStackMsg((ICall_Hdr *)pMsg);
            }
        }

        if (pMsg)
        {
          ICall_freeMsg(pMsg);
        }
      }

      // If RTOS queue is not empty, process app message.
      while (!Queue_empty(appMsgQueue))
      {
        sbbEvt_t *pMsg = (sbbEvt_t *)Util_dequeueMsg(appMsgQueue);
        if (pMsg)
        {
          // Process message.
          SimpleBLEBroadcaster_processAppMsg(pMsg);

          // Free the space from the message.
          ICall_free(pMsg);
        }
      }


    }

    // ----------------------------------------------------------------------
    // TODO: CAM: Handle normal events
    // ----------------------------------------------------------------------
    processAppSpecificEvents();
    if (isActive && sensorEvents){
    	updateAdvertismentData(); // update buffer for advertisement data
    	GAPRole_SetParameter(GAPROLE_ADVERT_DATA, sizeof(AdlAdvertData), AdlAdvertData); // set buffer for advertisement

    	GAPRole_SetParameter(GAPROLE_ADVERT_ENABLED, sizeof(uint8_t), &AdvEnable);	// Enable Advertisement
    	tx_repeat_counter = 0; // set repeat counter to zero
    }

  }
}



// TODO: CAM: process events related to ADL-Sensor node
/*********************************************************************
 * @fn      processAppSpecificEvents
 *
 * @brief   handles alle events from SCS, PIR, Accel or REED
 *
 * @param   void -
 *
 * @return  none
 */
void processAppSpecificEvents(void){

	// ---------------------------------------------------------------
    // TODO: CAM: handle key-press event
	// ---------------------------------------------------------------
    if (events & SBB_KEY_CHANGE_EVT)
    {
    	// clear event flag
      events &= ~SBB_KEY_CHANGE_EVT;

      // toggle between active and passive state
      if (isActive){

    	  scifStopRtcTicks();
    	  isActive = 0;
    	  processAccelEvents = 0;
    	  processPirEvents = 0;
    	  processReedEvents = 0;
    	  processScsEvents = 0;
    	  PIN_setOutputValue(pinHandle,Board_PIR_PWR, 0);
      }else{

    	  PIN_setOutputValue(pinHandle,Board_PIR_PWR, 1);
    	  isActive = 1;
    	  processAccelEvents = 1;
    	  processPirEvents = 1;
    	  processReedEvents = 1;
    	  processScsEvents = 1;
    	  sensorEvents = 0x00;
    	  scifStartRtcTicksNow(SCIF_RTC_TICKS);
      }
      // set sensorEvents for advertisment
      // sensorEvents |= KEY_CHANGE_EVT;
      // GAPRole_SetParameter(GAPROLE_ADVERT_DATA, sizeof(sensorData), sensorData);

      // Trigger advertisment
      // GAPRole_SetParameter(GAPROLE_ADVERT_ENABLED, sizeof(uint8_t), &AdvEnable);
    }



    // ---------------------------------------------------------------
    // TODO: CAM: handle periodic event
    // ---------------------------------------------------------------
    if (events & SBB_PERIODIC_EVT)
    {
    	// clear event flag
      events &= ~SBB_PERIODIC_EVT;
      if (processPeriodicEvents){
          // set sensorEvents for advertisment
          sensorEvents |= PERIODIC_EVT;

          Util_startClock(&periodicClock);

          // Perform periodic application task
          blinkLED(1,20e3);
      }

    }




    // ---------------------------------------------------------------
    // TODO: CAM: handle Sensor Controller Task Alert Event
    // ---------------------------------------------------------------
    if (events & SBB_SC_TASK_ALERT)
    {
    	scifClearAlertIntSource();
    	// clear event flag
    	events &= ~SBB_SC_TASK_ALERT;

    	if (processScsEvents){

			// set sensorEvents for advertisment
			sensorEvents |= SC_TASK_ALERT;
        	processSensorData();
        	blinkLED(1,20e3);
			// Clear the ALERT interrupt source
    	}
    	 // Acknowledge the alert event
    	 scifAckAlertEvents();
    }


    // ---------------------------------------------------------------
    // TODO: CAM: handle accelerometer events
    // ---------------------------------------------------------------
    if (events & SBB_ACCEL_EVT)
    {
    	// clear event flag
    	events &= ~SBB_ACCEL_EVT;



    	if (processAccelEvents){
        	// set sensorEvents for advertisment
        	sensorEvents |= ACCEL_EVT;
    		blinkLED(1,20e3);

    	}

    }


    // ---------------------------------------------------------------
    // TODO: CAM: handle PIR events
    // ---------------------------------------------------------------
    if (events & SBB_PIR_EVT)
    {
    	// clear event flag
    	events &= ~SBB_PIR_EVT;
    	if (processPirEvents){
        	// set sensorEvents for advertisment
        	sensorEvents |= PIR_EVT;
    		blinkLED(1,20e3);
    	}



    }


    // ---------------------------------------------------------------
    // TODO: CAM: handle REED events
    // ---------------------------------------------------------------
    if (events & SBB_REED_EVT)
    {
    	// clear event flag
    	events &= ~SBB_REED_EVT;



    	if(processReedEvents){
        	// set sensorEvents for advertisment
        	sensorEvents |= REED_EVT; // while flag will be overwritten in updateAdvertisementData, setting this flag here is needed to tringger a data transmission
    		blinkLED(1,20e3);
    	}

    }

}




// TODO: CAM: initialize the SensorControllerStudio
/*********************************************************************
 * @fn      initSensorControllerStudio
 *
 * @brief   initialize and configure the Sensor Controller Studio
 *
 * @param   void -
 *
 * @return  none
 */
void initSensorControllerStudio(void){

	  scifOsalInit();
	  scifOsalRegisterCtrlReadyCallback(scCtrlReadyCallback);
	  scifOsalRegisterTaskAlertCallback(scTaskAlertCallback);
	  scifInit(&scifDriverSetup);

	  // CAM: Set the Sensor Controller task tick interval
	  scifStartRtcTicksNow(SCIF_RTC_TICKS);

	  // CAM Start Sensor Controller Task
	  scifStartTasksNbl(BV(SCIF_READ_LIGHT_TEMPERATURE_AND_HUMIDITY_TASK_ID));

}

// TODO: CAM: update SensorData array to be sent
/*********************************************************************
 * @fn      updateSensorData
 *
 * @brief   update the array to be sent
 *
 * @param   void -
 *
 * @return  none
 */
void updateAdvertismentData(void){
	AdlAdvertData[MSB_Temp] = (uint8_t)((Temperature >>  8) & 0xFF );
	AdlAdvertData[LSB_Temp] = (uint8_t)((Temperature >>  0) & 0xFF );

	AdlAdvertData[MSB_Humid] = (uint8_t)((Humidity >>  8) & 0xFF );
	AdlAdvertData[LSB_Humid] = (uint8_t)((Humidity >>  0) & 0xFF );

	AdlAdvertData[MSB_LUX] = (uint8_t)((Light >>  8) & 0xFF );
	AdlAdvertData[LSB_LUX] = (uint8_t)((Light >>  0) & 0xFF );

	AdlAdvertData[MSB_Acc_X] = (uint8_t)((Accel_X_out >>  8) & 0xFF );
	AdlAdvertData[LSB_Acc_X] = (uint8_t)((Accel_X_out >>  0) & 0xFF );

	AdlAdvertData[MSB_Acc_Y] = (uint8_t)((Accel_Y_out >>  8) & 0xFF );
	AdlAdvertData[LSB_Acc_Y] = (uint8_t)((Accel_Y_out >>  0) & 0xFF );

	AdlAdvertData[MSB_Acc_Z] = (uint8_t)((Accel_Z_out >>  8) & 0xFF );
	AdlAdvertData[LSB_Acc_Z] = (uint8_t)((Accel_Z_out >>  0) & 0xFF );
	if (PIN_getInputValue(Board_REED)){

		sensorEvents |= REED_EVT; // Set event-flag to indicate the state of the REED-Switch
	}else{
		sensorEvents &= ~REED_EVT;
	}
	AdlAdvertData[UPDATE_IRQ] = sensorEvents;

	AdlAdvertData[BATTERY_LEVEL] = (uint8_t)AONBatMonBatteryVoltageGet();

	AdlAdvertData[TX_COUNTER] = tx_counter;

	// tx_counter = tx_counter +1; // Moved to main

	// reset sensor events
	sensorEvents = 0x00;

}

// TODO: CAM: process sensore data
/*********************************************************************
 * @fn      processSensorData
 *
 * @brief   get and process callibration and sensor data from HTS221
 *
 * @param   void -
 *
 * @return  none
 */
void processSensorData(void){

	if (FirstScsEvent){
		// get callibration values
		T0_degC = (scifTaskData.readLightTemperatureAndHumidity.cfg.T0degCS16x8 >> 3);
		T1_degC = (scifTaskData.readLightTemperatureAndHumidity.cfg.T1degCS16x8 >> 3);
		T0_out = scifTaskData.readLightTemperatureAndHumidity.cfg.T0out;
		T1_out = scifTaskData.readLightTemperatureAndHumidity.cfg.T1out;
		H0Rh = (scifTaskData.readLightTemperatureAndHumidity.cfg.H0RhX2 >> 1);
		H1Rh = (scifTaskData.readLightTemperatureAndHumidity.cfg.H1RhX2 >> 1);
		H0T0_out = scifTaskData.readLightTemperatureAndHumidity.cfg.H0T0out;
		H1T0_out = scifTaskData.readLightTemperatureAndHumidity.cfg.H1T0out;

		// save raw data
		Hout = scifTaskData.readLightTemperatureAndHumidity.output.Hout;
		Tout = scifTaskData.readLightTemperatureAndHumidity.output.Tout;
		Light = scifTaskData.readLightTemperatureAndHumidity.output.Lout;
		Accel_X_out = scifTaskData.readLightTemperatureAndHumidity.output.Xout;
		Accel_Y_out = scifTaskData.readLightTemperatureAndHumidity.output.Yout;
		Accel_Z_out = scifTaskData.readLightTemperatureAndHumidity.output.Zout;

		// calibrate
		getHumidity(&Humidity);
		getTemperature(&Temperature);

		// reset flag
		FirstScsEvent = 0;

	} else{

   		// save raw data
		Hout = scifTaskData.readLightTemperatureAndHumidity.output.Hout;
		Tout = scifTaskData.readLightTemperatureAndHumidity.output.Tout;
		Light = scifTaskData.readLightTemperatureAndHumidity.output.Lout;
		Accel_X_out = scifTaskData.readLightTemperatureAndHumidity.output.Xout;
		Accel_Y_out = scifTaskData.readLightTemperatureAndHumidity.output.Yout;
		Accel_Z_out = scifTaskData.readLightTemperatureAndHumidity.output.Zout;

		// calibrate
		getHumidity(&Humidity);
		getTemperature(&Temperature);

	 }
}

// TODO: CAM: calibrate Humidity
/*********************************************************************
 * @fn      getHumidity
 *
 * @brief   calibrate humidity from HTS221
 *
 * @param   *value - pointer to humidity
 *
 * @return  none
 */
void getHumidity(uint16_t * value){
	int32_t tmp;
	tmp = ((uint32_t)(Hout - H0T0_out)) * ((uint32_t)(H1Rh - H0Rh)*10);
	*value = tmp/(H1T0_out-H0T0_out) + H0Rh*10;
	if(*value>1000 ) {
		*value = 1000;
	}
}
// TODO: CAM: calibrate Temperature
/*********************************************************************
 * @fn      getTemperature
 *
 * @brief   calibrate temperature from HTS221
 *
 * @param   *void - pointer to temperature
 *
 * @return  none
 */
void getTemperature(int16_t *value){
	int32_t tmp32;
	tmp32 = ((int32_t)(Tout - T0_out)) * ((int32_t)(T1_degC - T0_degC)*10);
	*value = tmp32 /(T1_out - T0_out) + T0_degC*10;
}


// TODO: CAM: added Sensor Controll Alert Callback
/*********************************************************************
 * @fn      scTaskAlertCallback
 *
 * @brief   Sensor Controller Alert Callback
 *
 * @param   void -
 *
 * @return  none
 */
void scTaskAlertCallback(void) {
	// Add event-flag
	events |= SBB_SC_TASK_ALERT;
    // Wake up the OS task
    Semaphore_post(sem);

} // scTaskAlertCallback


// TODO: CAM: added Sensor Controll Ready Callback
/*********************************************************************
 * @fn      scCtrlReadyCallback
 *
 * @brief   Controll Ready Callback
 *
 * @param   void -
 *
 * @return  none
 */
static void scCtrlReadyCallback(void) {

} // scCtrlReadyCallback


// TODO: CAM: added blinking LED
/*********************************************************************
 * @fn      blinkLED
 *
 * @brief   blink LED
 *
 * @param   times - how often to blink
 * @param   delay - how long (in uS) the LED is ON
 *
 * @return  none
 */
static void blinkLED(uint8_t times, uint32_t delay){
    uint8_t i = 0;
    for (i=0; i<times; i++){
    	PIN_setOutputValue(pinHandle, Board_LED_1, Board_LED_ON);
        Task_sleep(delay/Clock_tickPeriod);
        PIN_setOutputValue(pinHandle, Board_LED_1, Board_LED_OFF);
        Task_sleep(delay/Clock_tickPeriod);
    }
}


// TODO: CAM: added pinInterruptHandler
/*********************************************************************
 * @fn      pinInterruptHandler
 *
 * @brief   Process key interrupts. Post sem to wake up app
 *
 * @param   hande - handle to pins
 * @param   pinID - id of the pin
 *
 * @return  none
 */
static void pinInterruptHandler(PIN_Handle handle, PIN_Id pinId){
	// events flag for internal application events.
	if (pinId == Board_KEY){
		events |= SBB_KEY_CHANGE_EVT;
	}
	if (pinId == Board_ACCEL_INT2){
		events |= SBB_ACCEL_EVT;
	}
	if (pinId == Board_PIR_IRQ){
		events |= SBB_PIR_EVT;
	}
	if (pinId == Board_REED){
		events |= SBB_REED_EVT;
	}

	Semaphore_post(sem);
}



// TODO: CAM: added support for periodic events
/*********************************************************************
 * @fn      SimpleBLEPeripheral_clockHandler
 *
 * @brief   Handler function for clock timeouts.
 *
 * @param   arg - event type
 *
 * @return  None.
 */
static void SimpleBLEBroadcaster_clockHandler(UArg arg)
{
  // Store the event.
  events |= arg;

  // Wake up the application.
  Semaphore_post(sem);
}







/*********************************************************************
 * @fn      SimpleBLEBroadcaster_processStackMsg
 *
 * @brief   Process an incoming stack message.
 *
 * @param   pMsg - message to process
 *
 * @return  none
 */
static void SimpleBLEBroadcaster_processStackMsg(ICall_Hdr *pMsg)
{
  switch (pMsg->event)
  {
    default:
      // do nothing
      break;
  }
}

/*********************************************************************
 * @fn      SimpleBLEPeripheral_processAppMsg
 *
 * @brief   Process an incoming callback from a profile.
 *
 * @param   pMsg - message to process
 *
 * @return  none
 */                       
static void SimpleBLEBroadcaster_processAppMsg(sbbEvt_t *pMsg)
{
  switch (pMsg->hdr.event)
  {
    case SBB_STATE_CHANGE_EVT:
      SimpleBLEBroadcaster_processStateChangeEvt((gaprole_States_t)pMsg->
                                                 hdr.state);
      break;
      
    default:
      // Do nothing.
      break;
  }
}

/*********************************************************************
 * @fn      SimpleBLEBroadcaster_stateChangeCB
 *
 * @brief   Callback from GAP Role indicating a role state change.
 *
 * @param   newState - new state
 *
 * @return  none
 */
static void SimpleBLEBroadcaster_stateChangeCB(gaprole_States_t newState)
{
  sbbEvt_t *pMsg;
  
  // Create dynamic pointer to message.
  if (pMsg = ICall_malloc(sizeof(sbbEvt_t)))
  {
    pMsg->hdr.event = SBB_STATE_CHANGE_EVT;
    pMsg->hdr.state = newState;
    
    // Enqueue the message.
    Util_enqueueMsg(appMsgQueue, sem, (uint8*)pMsg);
  }
}

/*********************************************************************
 * @fn      SimpleBLEBroadcaster_processStateChangeEvt
 *
 * @brief   Notification from the profile of a state change.
 *
 * @param   newState - new state
 *
 * @return  none
 */
static void SimpleBLEBroadcaster_processStateChangeEvt(gaprole_States_t newState)
{
  switch (newState)
  {
    case GAPROLE_STARTED:
      {
        uint8 ownAddress[B_ADDR_LEN];
        
        GAPRole_GetParameter(GAPROLE_BD_ADDR, ownAddress);
        
        // Display device address 
        LCD_WRITE_STRING(Util_convertBdAddr2Str(ownAddress), LCD_PAGE1);
        LCD_WRITE_STRING("Initialized", LCD_PAGE2);
      }
      break;
      
    case GAPROLE_ADVERTISING:
      {
        LCD_WRITE_STRING("Advertising", LCD_PAGE2);        
      }
      break;

    case GAPROLE_WAITING:
      {
        LCD_WRITE_STRING("Waiting", LCD_PAGE2);       
      }
      break;          

    case GAPROLE_ERROR:
      {
        LCD_WRITE_STRING("Error", LCD_PAGE2);         
      }
      break;      
      
    default:
      {
        LCD_WRITE_STRING("", LCD_PAGE2);
      }
      break; 
  }
}


/*********************************************************************
*********************************************************************/
