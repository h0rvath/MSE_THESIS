import sqlite3
import requests
import logging
import time

# logging.basicConfig(level=logging.DEBUG)
logger1 = logging.getLogger(__name__)


#logger1.setLevel(logging.ERROR)

class uploader(object):
    # post_url = "https://home4dem-data.ihomelab.ch/upload/data-collection?token=testtoken"
    post_url = "https://data.home4dem.ihomelab.ch/upload/data-collection?token=testtoken"
    version = "1.0"
    payload = {"version": version, "dataset": []}

    def __init__(self, sqlite_file):
        self.sqlite_file = sqlite_file
        self.openSQLiteDB()

    def openSQLiteDB(self):
        try:
            self.sql_conn = sqlite3.connect(self.sqlite_file, check_same_thread=False, timeout=30)
            self.sql_conn.row_factory = sqlite3.Row
            self.cursor = self.sql_conn.cursor()
        except Exception as e:
            logger1.exception(" Exception while opening SQLiteDB \n")

    def closeSQLConnection(self):
        try:
            logger1.info("Try to close DB \n")
            self.sql_conn.commit()
            self.sql_conn.close()
        except Exception as e:
            logger1.exception(" Exception while closing SQLiteDB \n")

    def sendData(self):
        error = -1
        try:
            # sql_conn = sqlite3.connect(self.sqlite_file, check_same_thread=False, timeout=30)
            # sql_conn.row_factory = sqlite3.Row
            # cursor = sql_conn.cursor()
            data = self.cursor.execute("select rowid, * from Data where uploaded = '0' LIMIT 10000")

            fetched = data.fetchall()
            data_length = len(fetched)
            if (data_length > 0):
                dataset = []
                rowids = []
                for row in fetched:
                    dataset.append(dict(row))

                for row in dataset:
                    rowids.append(row['rowid'])
                    row.pop('hash')


                self.payload["dataset"] = dataset

                r = requests.post(self.post_url, json=self.payload)

                rec = dict(r.json())
                info = rec['alerts']['info'][0]
                logger1.info("Response from server: %s", info)
                if (info == 'Data successfully stored!'):
                    self.cursor.executemany("UPDATE Data SET uploaded = '1' where rowid = (?)",
                                            ((value,) for value in rowids))
                    self.sql_conn.commit()
                    if (data_length == 10000):
                        error = -2
                    else:
                        error = 0
                else:
                    logger1.error(" Error while sending data to server \n")
        except Exception as e:
            logger1.exception(" Exception while sending data to server\n")
            error = -1

        finally:
            self.sql_conn.commit()
            return error
            # sql_conn.close()

    def delDuplicated(self):
        try:
            ret = self.cursor.execute('DELETE FROM Data WHERE RowId NOT IN (SELECT MIN(RowId) FROM Data GROUP BY hash)')
            self.sql_conn.commit()
        except Exception as e:
            logger1.exception(e)
        finally:
            self.sql_conn.commit()

    def logData(self, data):
        logger1.info('Logging Data')
        try:
            data.getData()
            # sql_conn = sqlite3.connect(self.sqlite_file, check_same_thread=False, timeout=30)
            # curser = sql_conn.cursor()
            self.cursor.execute("INSERT INTO Data VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", \
                                [
                                    data.time,
                                    data.addr,
                                    data.rssi,
                                    data.brightness,
                                    data.temperature,
                                    data.humid,
                                    data.battery,
                                    data.counter,
                                    data.PIR_EVT,
                                    data.ACCEL_EVT,
                                    data.SC_TASK_ALERT,
                                    data.PERIODIC_EVT,
                                    data.accel_x,
                                    data.accel_y,
                                    data.accel_z,
                                    data.REED_EVT,
                                    '0',
                                    data.hash
                                ])
            self.sql_conn.commit()
        except Exception as e:
            logger1.exception(" Exception in logData\n")

        finally:
            self.sql_conn.commit()
            # self.sql_conn.close()
