import logging
import logging.handlers
import logging.config
import sqlite3
import threading
import time
from datetime import datetime
import pytz
import os.path
import subprocess
import queue

from bluepy.btle import Scanner

from logger import ScanDelegate

from upload import uploader

# set up logging to file - see previous section for more details
scriptpath = os.path.dirname(__file__)
configPath = os.path.join(scriptpath, 'logger_config.conf')
logging.config.fileConfig(configPath, disable_existing_loggers=False)
logger1 = logging.getLogger(__name__)

sqlite_path = os.path.join(scriptpath, 'SQL_Files/ADL_Logger_DB.sqlite')



def creatingSQLiteDB():
    global sqlite_path
    ending = datetime.now(tz=pytz.timezone('Europe/Zurich')).strftime("%Y-%m-%d")
    sqlite_file = sqlite_path.replace('_DB', '_' + ending)
    sql_conn = sqlite3.connect(sqlite_file, check_same_thread=False, timeout=30)
    cursor = sql_conn.cursor()
    logger1.info(" Setting up SQLite DB")
    # cur.execute('DROP TABLE IF EXISTS Data')
    cursor.execute('''CREATE TABLE IF NOT EXISTS
    Data(
        timestamp TEXT,
        sensorNodeId TEXT,
        rssi INTEGER,
        brightness INTEGER,
        temperature REAL,
        humidity REAL,
        battery INTEGER,
        counter INTEGER,
        pir_evt INTEGER,
        accel_evt INTEGER,
        scs_evt INTEGER,
        periodic_evt INTEGER,
        accel_x REAL,
        accel_y REAL,
        accel_z REAL,
        reed_evt INTEGER,
        uploaded INTEGER,
        hash TEXT
        )''')
    sql_conn.commit()
    cursor.execute("SELECT * FROM Data")
    sql_conn.commit()
    logger1.info(" SQLite DB created: ")
    # logger1.info(list(map(lambda x: x[0], cursor.description)))
    sql_conn.close()
    logger1.info(" DB ready")

    return sqlite_file


def main():

    logger1.info(" ************************************")
    logger1.info(" Weclom to the ADL-Sensor Datalogger")
    logger1.info(" ************************************")

    sqlite_file = creatingSQLiteDB()

    logger1.info(" Start logger")

    try:

        # getting the correct interface
        s = str(subprocess.check_output("hciconfig").decode())
        a = s.split('\n')
        interface = ''
        for i in a:
            if 'USB' in i:
                interface = str(i)[3]
                logger1.info('Using BLE-Interface: {}'.format(interface))
        if interface == '':
            logger1.error('No USB-BLE-Stick found\n')
            raise Exception

        th_event = threading.Event()
        workQueue = queue.Queue()

        scanner = Scanner(int(interface)).withDelegate(ScanDelegate(th_event, workQueue))
        scanner_th = threading.Thread(target=scanner.scan, args=(0,))
        scanner_th.start()
        upload = uploader(sqlite_file)

        today = datetime.now().day
        while 1:

            error = -1 # Error message from uploader
            time_1 = time.time()

            while ((time.time() - time_1) < 300):
                if not workQueue.empty():
                    data = workQueue.get()
                    upload.logData(data)

                else:
                    time.sleep(1)

            if (time.time() - time_1) > 300:
                #logger1.error('Queue length: {}'.format(workQueue.qsize()))
                upload.delDuplicated()
                error = upload.sendData()
                logger1.error('Queue length: {}'.format(workQueue.qsize()))

            if ( (datetime.now().day != today) and (error == 0)):
                logger1.error('Change SQL-DB')
                upload.closeSQLConnection()
                sqlite_file = creatingSQLiteDB()
                upload = uploader(sqlite_file)
                logger1.error('New DB-Name is: {}'.format(sqlite_file))
                today = datetime.now().day

            if (abs(datetime.now().day - today) >= 5): # To prevent big delay due to a big database
                logger1.error('Forced change of SQL-DB')
                upload.closeSQLConnection()
                sqlite_file = creatingSQLiteDB()
                upload = uploader(sqlite_file)
                logger1.error('New DB-Name is: {}'.format(sqlite_file))
                today = datetime.now().day

            if (scanner_th.is_alive()):
                pass

            else:
                logger1.error(" BLE-Stick removed or damaged \n")
                raise Exception

    except Exception as e:
        logging.exception("Exception in main() task \n")
        logger1.error(" Error occured \n")

        upload.closeSQLConnection()
        th_event.set()



        # sql_conn.commit()
        # cur.execute("SELECT name FROM sqlite_master WHERE type='table';")
        # logger1.info(cur.fetchall())
        # sql_conn.close()


if __name__ == '__main__':
    main()
