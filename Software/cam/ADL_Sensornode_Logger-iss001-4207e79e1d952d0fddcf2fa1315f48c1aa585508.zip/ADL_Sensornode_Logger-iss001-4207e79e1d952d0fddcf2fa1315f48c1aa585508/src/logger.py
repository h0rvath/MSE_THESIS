from bluepy.btle import DefaultDelegate
import array
from datetime import datetime
import pytz
import logging
import hashlib


# logging.basicConfig(level=logging.DEBUG)
logger1 = logging.getLogger(__name__)


# logger1.setLevel(logging.ERROR)


class SensorData():
    def __init__(self, rawData, time, rssi, addr):
        self.local = pytz.timezone('Europe/Zurich')
        self.rawData = rawData
        self.time = time
        self.rssi = rssi
        self.addr = addr

        self.brightness = 0
        self.temperature = 0
        self.battery = 0
        self.counter = 0
        self.humid = 0
        self.PIR_EVT = 0
        self.REED_EVT = 0
        self.ACCEL_EVT = 0
        self.PERIODIC_EVT = 0
        self.SC_TASK_ALERT = 0
        self.KEY_CHANGE_EVT = 0
        self.accel_x = 0
        self.accel_y = 0
        self.accel_z = 0
        self.hash = 0

        self.SCS_MSK = 1
        self.ACCEL_MSK = 2
        self.PIR_MSK = 4
        self.REED_MSK = 8
        self.KEY_MSK = 16
        self.PERIODIC_MSK = 32

    def getData(self):
        try:
            self.brightness = int.from_bytes(self.rawData[2:4], byteorder='big')
            self.temperature = int.from_bytes(self.rawData[4:6], byteorder='big', signed=True) / 10
            self.humid = int.from_bytes(self.rawData[6:8], byteorder='big') / 10
            self.accel_x = int.from_bytes(self.rawData[8:10], byteorder='big', signed=True) / (2 ** 15 - 1) * 2
            self.accel_y = int.from_bytes(self.rawData[10:12], byteorder='big', signed=True) / (2 ** 15 - 1) * 2
            self.accel_z = int.from_bytes(self.rawData[12:14], byteorder='big', signed=True) / (2 ** 15 - 1) * 2
            self.battery = self.rawData[15]
            self.counter = int.from_bytes(self.rawData[16:18], byteorder='little', signed=False)

            events = int(self.rawData[14])
            if (events & self.PIR_MSK): self.PIR_EVT = 1
            if (events & self.REED_MSK): self.REED_EVT = 1
            if (events & self.ACCEL_MSK): self.ACCEL_EVT = 1
            if (events & self.PERIODIC_MSK): self.PERIODIC_EVT = 1
            if (events & self.SCS_MSK): self.SC_TASK_ALERT = 1
            if (events & self.KEY_MSK): self.KEY_CHANGE_EVT = 1

            self.hash = hashlib.sha1(self.rawData).hexdigest()
            logger1.info('Hash is: {}'.format(self.hash))

        except Exception as e:
            logger1.exception(" Exception in getData \n")


class ScanDelegate(DefaultDelegate):
    def __init__(self, th_event, queue, logFile=False, ):
        DefaultDelegate.__init__(self)
        self.th_event = th_event
        self.queue = queue
        self.logFile = logFile

    def handleDiscovery(self, dev, isNewDev, isNewData):
        if self.th_event.is_set():
            # self.closeSQLConnection()
            raise ValueError('Error in main thread occured, shutting down logger thread')

        if (dev.addr.startswith('a0:e6:f8') or dev.addr.startswith('b0:91:22')):
            try:
                self.rawData = array.array('B', dev.rawData)
                if len(self.rawData) == 18:
                    self.local = pytz.timezone('Europe/Zurich')
                    self.time = datetime.now(tz=self.local).strftime("%Y-%m-%d %H:%M:%S.%f%z")

                    self.rssi = dev.rssi
                    self.addr = dev.addr
                    data = SensorData(self.rawData, self.time, self.rssi, self.addr)
                    self.queue.put(data)

                    self.printData()

            except Exception as e:
                logger1.exception(" Exception in handleDiscovery \n")

    def printData(self):
        logger1.info("*****************************************************")
        logger1.info("Device %s, RSSI=%d dB" % (self.addr, self.rssi))
        logger1.info("*****************************************************")
        logger1.info('')
        logger1.info(self.rawData)




        if (self.logFile):
            self.data['timestamp'] = self.time
            self.data['sensorNodeId'] = self.addr
            self.data['rssi'] = self.rssi
            self.data['brightness'] = self.brightness
            self.data['temperature'] = self.temperature
            self.data['humidity '] = self.humid
            self.data['battery'] = self.battery
            self.data['counter'] = self.counter
            self.data['pir_evt'] = self.PIR_EVT
            self.data['accel_evt'] = self.ACCEL_EVT
            self.data['scs_evt'] = self.SC_TASK_ALERT
            self.data['periodic_evt'] = self.PERIODIC_EVT
            self.data['accel_x'] = self.accel_x
            self.data['accel_y'] = self.accel_y
            self.data['accel_z'] = self.accel_z
            self.data['reed_evt'] = self.REED_EVT
