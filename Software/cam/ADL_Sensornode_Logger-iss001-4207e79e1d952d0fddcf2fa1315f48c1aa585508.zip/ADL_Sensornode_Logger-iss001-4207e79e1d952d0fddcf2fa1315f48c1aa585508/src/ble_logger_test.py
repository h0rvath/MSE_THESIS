import logging
import sqlite3
import threading
import time
import sys
import os.path
import subprocess

from bluepy.btle import Scanner

from logger import ScanDelegate

from upload import uploader

# set up logging to file - see previous section for more details
scriptpath = os.path.dirname(__file__)
logfilepath = os.path.join(scriptpath, 'ADL_Logger.log')
logging.basicConfig(level=logging.ERROR,
                    format= '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    # datefmt='%m-%d %H:%M',
                    filename=logfilepath,
                    filemode='a')
# define a Handler which writes INFO messages or higher to the sys.stderr
console = logging.StreamHandler()
console.setLevel(logging.INFO)


# set a format which is simpler for console use
formatter = logging.Formatter('%(name)-12s: %(levelname)-8s %(message)s')
# tell the handler to use this format
console.setFormatter(formatter)
# add the handler to the root logger
logging.getLogger('').addHandler(console)

logger1 = logging.getLogger(__name__)



sqlite_file = 'ADL_Logger_DB.sqlite'
table_name = 'data'
sql_conn = sqlite3.connect(sqlite_file,check_same_thread=False, timeout=30)
cursor = sql_conn.cursor()

def creatingSQLiteDB():
    global cursor
    global sql_conn
    logger1.info(" Setting up SQLite DB")
    #cur.execute('DROP TABLE IF EXISTS Data')
    cursor.execute('''CREATE TABLE IF NOT EXISTS
    Data(
        timestamp TEXT,
        sensorNodeId TEXT,
        rssi INTEGER,
        brightness INTEGER,
        temperature REAL,
        humidity REAL,
        battery INTEGER,
        counter INTEGER,
        pir_evt INTEGER,
        accel_evt INTEGER,
        scs_evt INTEGER,
        periodic_evt INTEGER,
        accel_x REAL,
        accel_y REAL,
        accel_z REAL,
        reed_evt INTEGER,
        uploaded INTEGER
        )''')
    sql_conn.commit()
    cursor.execute("SELECT * FROM Data")
    sql_conn.commit()
    logger1.info(" SQLite DB created: ")
    logger1.info(list(map(lambda x: x[0], cursor.description)))
    sql_conn.close()
    logger1.info(" DB ready")


def main():
    global sqlite_file
    global sql_conn
    logger1.info(" ************************************")
    logger1.info(" Weclom to the ADL-Sensor Datalogger")
    logger1.info(" ************************************")


    creatingSQLiteDB()



    logger1.info(" Start logger")
    try:
        th_event = threading.Event()
        # getting the correct interface
        s = str(subprocess.check_output("hciconfig").decode())
        a = s.split('\n')
        interface = ''
        for i in a:
            if 'USB' in i:
                interface = str(i)[3]
                print('Using BLE-Interface: {}'.format(interface))
        if interface == '':
            logger1.error('No USB-BLE-Stick found')
            raise Exception
        

        scanner = Scanner(int(interface)).withDelegate(ScanDelegate(th_event, sqlite_file))
        scanner_th = threading.Thread(target=scanner.scan, args=(0,))
        scanner_th.start()
        #upload = uploader(sqlite_file)

        while 1:
            if (scanner_th.is_alive()):
#                logger1.info(" Sending Data from Main")
                #upload.sendData()
                time.sleep(1)
                
            else:
                logger1.error(" BLE-Stick removed or damaged")
                break

    except Exception as e:
        logging.exception("Exception in main() task")
        logger1.error(" Error occured")
        logger1.error(" Closing SQLite DB")

        #upload.closeSQLConnection()
        th_event.set()



        #sql_conn.commit()
        #cur.execute("SELECT name FROM sqlite_master WHERE type='table';")
        #print(cur.fetchall())
        #sql_conn.close()


if __name__ == '__main__':
    main()




