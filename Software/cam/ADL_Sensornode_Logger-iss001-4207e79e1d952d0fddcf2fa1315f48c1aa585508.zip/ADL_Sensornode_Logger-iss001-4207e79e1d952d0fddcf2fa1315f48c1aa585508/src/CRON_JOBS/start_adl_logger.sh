#!/bin/bash
startLogger() {
  /usr/bin/python3 /home/pi/ADL_Sensornode_Logger/src/ble_logger.py
  if [[ $? -eq 0 ]]; then
    echo logger created successfully
  else
    echo An error occurred creating a logger. RC was $?
  fi
}

ps axf | grep ble_logger.py | grep -v grep

if [[ $? -ne 0 ]]; then
  echo Creating new adl_logger
  startLogger
fi

