#!/bin/bash
createTunnel() {
  /usr/bin/autossh -M 10984 -N -f -o "PubkeyAuthentication=yes" -o "PasswordAuthentication=no" -i /pi/.ssh/id_rsa -R 65011:localhost:22 relaxedcare@147.88.219.198 -p 8624
  if [[ $? -eq 0 ]]; then
    echo Tunnel created successfully
  else
    echo An error occurred creating a tunnel. RC was $?
  fi
}
/bin/pidof autossh
if [[ $? -ne 0 ]]; then
  echo Creating new tunnel connection
  createTunnel
fi

